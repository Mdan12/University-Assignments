package vinnsla;

public interface Styleable {
    public void getStyleClass();
}
